package id.yoruka.shrunner

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var logView: TextView
    private lateinit var runButton: Button
    private lateinit var profileView: ImageView
    private val scriptPath = "/data/local/tmp/pepek/start.sh"
    private val profileRequest = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(5, 9, 20)
        window.navigationBarColor = Color.rgb(5, 9, 20)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(5, 9, 20)) }
        val watermark = ImageView(this).apply {
            setImageResource(R.drawable.logo_watermark)
            scaleType = ImageView.ScaleType.FIT_CENTER
            alpha = 0.22f
        }
        root.addView(watermark, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(16))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(12), dp(10), dp(12))
            background = rounded(Color.argb(220, 13, 24, 45), dp(16))
        }
        val brand = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val developer = TextView(this).apply {
            text = "TENZZXN-DEV"
            textSize = 12f
            letterSpacing = 0.18f
            setTextColor(Color.rgb(65, 166, 255))
            setTypeface(null, Typeface.BOLD)
        }
        val title = TextView(this).apply {
            text = "TENZZXN MODS"
            textSize = 21f
            letterSpacing = 0.04f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
        }
        brand.addView(developer)
        brand.addView(title)
        header.addView(brand, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        profileView = ImageView(this).apply {
            setImageResource(R.drawable.logo_profile)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(Color.rgb(0, 116, 255), dp(50))
            clipToOutline = true
            contentDescription = "Change profile"
            setOnClickListener { chooseProfile() }
        }
        header.addView(profileView, LinearLayout.LayoutParams(dp(52), dp(52)))
        content.addView(header, matchWrap())

        status = TextView(this).apply {
            text = "Status: siap"
            textSize = 14f
            setTextColor(Color.rgb(160, 205, 240))
            setPadding(dp(2), dp(18), 0, dp(12))
        }
        val path = TextView(this).apply {
            text = "Target: $scriptPath"
            textSize = 12f
            setTextColor(Color.LTGRAY)
        }
        runButton = makeButton("JALANKAN SCRIPT (ROOT)") { runScript() }
        val checkButton = makeButton("CEK AKSES ROOT") { checkRoot() }
        val openGameButton = makeButton("OPEN FREE FIRE MAX") { openFreeFireMax() }
        logView = TextView(this).apply {
            text = "Output akan tampil di sini.\n"
            textSize = 12f
            setTextColor(Color.rgb(220, 232, 245))
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        val scroll = ScrollView(this).apply {
            addView(logView)
            background = rounded(Color.argb(205, 12, 20, 35), dp(12))
        }
        content.addView(status, matchWrap())
        content.addView(path, matchWrap())
        content.addView(runButton, matchWrap())
        content.addView(checkButton, matchWrap())
        content.addView(openGameButton, matchWrap())
        content.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ).apply { topMargin = dp(14) })
        root.addView(content, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        setContentView(root)
        loadProfile()
    }

    private fun chooseProfile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, profileRequest)
    }

    @Deprecated("Use activity result API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == profileRequest && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            getSharedPreferences("tenzzxn", MODE_PRIVATE).edit().putString("profile_uri", uri.toString()).apply()
            profileView.setImageURI(uri)
            Toast.makeText(this, "Profile berhasil diubah", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadProfile() {
        val saved = getSharedPreferences("tenzzxn", MODE_PRIVATE).getString("profile_uri", null)
        if (saved != null) {
            try { profileView.setImageURI(Uri.parse(saved)) } catch (_: Exception) { }
        }
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
        setStroke(dp(1), Color.argb(90, 40, 145, 255))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun appendLog(line: String) { runOnUiThread { logView.append(line + "\n") } }

    private fun openFreeFireMax() {
        val intent = packageManager.getLaunchIntentForPackage("com.dts.freefiremax")
        if (intent == null) {
            Toast.makeText(this, "Free Fire MAX tidak ditemukan", Toast.LENGTH_SHORT).show()
            appendLog("[APP] Paket com.dts.freefiremax tidak ditemukan")
            return
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    }

    private fun checkRoot() {
        status.text = "Status: memeriksa root..."
        Thread {
            try {
                val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
                val output = BufferedReader(InputStreamReader(p.inputStream)).readText()
                val code = p.waitFor()
                runOnUiThread {
                    if (code == 0 && output.contains("uid=0")) {
                        status.text = "Status: root tersedia"
                        logView.append("[ROOT OK] $output\n")
                    } else {
                        status.text = "Status: root ditolak/tidak tersedia"
                        logView.append("[ROOT ERROR] ${output.ifBlank { "Tidak mendapat izin su" }}\n")
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Status: gagal memanggil su"
                    logView.append("[ERROR] ${e.message}\n")
                }
            }
        }.start()
    }

    private fun runScript() {
        runButton.isEnabled = false
        status.text = "Status: menjalankan..."
        logView.append("\n$ $scriptPath\n")
        Thread {
            try {
                val command = "if [ -f '$scriptPath' ]; then chmod 755 '$scriptPath'; sh '$scriptPath'; else echo 'File tidak ditemukan: $scriptPath'; exit 2; fi"
                val process = ProcessBuilder("su", "-c", command).redirectErrorStream(true).start()
                BufferedReader(InputStreamReader(process.inputStream)).use { reader ->
                    var line: String?
                    while (reader.readLine().also { line = it } != null) appendLog(line ?: "")
                }
                val exitCode = process.waitFor()
                runOnUiThread {
                    status.text = "Status: selesai (exit $exitCode)"
                    runButton.isEnabled = true
                }
            } catch (e: Exception) {
                appendLog("[ERROR] ${e.message}")
                runOnUiThread {
                    status.text = "Status: gagal menjalankan script"
                    runButton.isEnabled = true
                }
            }
        }.start()
    }
}

# TENZZXN MODS

Android app project with:
- Root script runner for `/data/local/tmp/pepek/start.sh` using `su -c`.
- Root permission check.
- Free Fire MAX launcher for package `com.dts.freefiremax`.
- TENZZXN MODS title with a subtle TZ watermark behind it.
- Live process output in the app.

## Build without Termux

This project includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.

1. Create a GitHub repository and upload/push the contents of this folder.
2. Open the repository's **Actions** tab.
3. Select **Build TENZZXN MODS APK** and press **Run workflow** (or push to `main`).
4. When the run finishes, open the run's **Artifacts** section and download `TENZZXN-MODS-debug`.
5. Extract the artifact to get `app-debug.apk`.

The workflow builds with JDK 17 and Gradle 8.11.1 on GitHub's hosted Ubuntu runner. It does not require Termux on the phone.

## Requirements at runtime

- Android device with KernelSU or Magisk (or another `su` provider).
- Approve the app's root permission request when prompted.
- Ensure `/data/local/tmp/pepek/start.sh` exists and contains a script you trust.
- Free Fire MAX must be installed to use its launch button.

The app invokes the script as root. Review `start.sh` before running it; root scripts can modify the device.

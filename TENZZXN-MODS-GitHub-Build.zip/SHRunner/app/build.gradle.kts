plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "id.yoruka.shrunner"
    compileSdk = 35

    defaultConfig {
        applicationId = "id.yoruka.shrunner"
        minSdk = 23
        targetSdk = 28
        versionCode = 1
        versionName = "1.0"
    }
}

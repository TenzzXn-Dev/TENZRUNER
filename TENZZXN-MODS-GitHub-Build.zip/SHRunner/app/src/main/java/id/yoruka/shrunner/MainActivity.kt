package id.yoruka.shrunner

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.Toast
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var logView: TextView
    private lateinit var runButton: Button
    private val scriptPath = "/data/local/tmp/pepek/start.sh"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(15, 18, 28)
        window.navigationBarColor = Color.rgb(15, 18, 28)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 20)
            setBackgroundColor(Color.rgb(15, 18, 28))
        }
        val header = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(20, 25, 39))
            setPadding(8, 18, 8, 18)
        }
        val logoMark = TextView(this).apply {
            text = "✦  TZ  ✦"
            textSize = 48f
            setTextColor(Color.argb(34, 90, 190, 255))
            gravity = Gravity.CENTER
        }
        val title = TextView(this).apply {
            text = "TENZZXN MODS"
            textSize = 25f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            letterSpacing = 0.08f
        }
        header.addView(logoMark, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER
        ))
        header.addView(title, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER
        ))
        status = TextView(this).apply {
            text = "Status: siap"
            textSize = 14f
            setTextColor(Color.rgb(160, 190, 210))
            setPadding(0, 18, 0, 12)
        }
        val path = TextView(this).apply {
            text = "Target: $scriptPath"
            textSize = 12f
            setTextColor(Color.LTGRAY)
        }
        runButton = Button(this).apply {
            text = "JALANKAN SCRIPT (ROOT)"
            setOnClickListener { runScript() }
        }
        val checkButton = Button(this).apply {
            text = "CEK AKSES ROOT"
            setOnClickListener { checkRoot() }
        }
        val openGameButton = Button(this).apply {
            text = "OPEN FREE FIRE MAX"
            setOnClickListener { openFreeFireMax() }
        }
        logView = TextView(this).apply {
            text = "Output akan tampil di sini.\n"
            textSize = 12f
            setTextColor(Color.rgb(210, 220, 230))
            setPadding(12, 12, 12, 12)
        }
        val scroll = ScrollView(this).apply {
            addView(logView)
            setBackgroundColor(Color.rgb(25, 30, 43))
        }
        root.addView(header, matchWrap())
        root.addView(status, matchWrap())
        root.addView(path, matchWrap())
        root.addView(runButton, matchWrap())
        root.addView(checkButton, matchWrap())
        root.addView(openGameButton, matchWrap())
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = 14 })
        setContentView(root)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun appendLog(line: String) {
        runOnUiThread { logView.append(line + "\n") }
    }

    private fun openFreeFireMax() {
        val intent = packageManager.getLaunchIntentForPackage("com.dts.freefiremax")
        if (intent == null) {
            Toast.makeText(this, "Free Fire MAX tidak ditemukan", Toast.LENGTH_SHORT).show()
            appendLog("[APP] Paket com.dts.freefiremax tidak ditemukan")
            return
        }
        intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    }

    private fun checkRoot() {
        status.text = "Status: memeriksa root..."
        Thread {
            try {
                val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
                val output = BufferedReader(InputStreamReader(p.inputStream)).readText()
                val code = p.waitFor()
                runOnUiThread {
                    if (code == 0 && output.contains("uid=0")) {
                        status.text = "Status: root tersedia"
                        logView.append("[ROOT OK] $output\n")
                    } else {
                        status.text = "Status: root ditolak/tidak tersedia"
                        logView.append("[ROOT ERROR] ${output.ifBlank { "Tidak mendapat izin su" }}\n")
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Status: gagal memanggil su"
                    logView.append("[ERROR] ${e.message}\n")
                }
            }
        }.start()
    }

    private fun runScript() {
        runButton.isEnabled = false
        status.text = "Status: menjalankan..."
        logView.append("\n$ $scriptPath\n")
        Thread {
            try {
                val command = "if [ -f '$scriptPath' ]; then chmod 755 '$scriptPath'; sh '$scriptPath'; else echo 'File tidak ditemukan: $scriptPath'; exit 2; fi"
                val process = ProcessBuilder("su", "-c", command)
                    .redirectErrorStream(true)
                    .start()
                BufferedReader(InputStreamReader(process.inputStream)).use { reader ->
                    var line: String?
                    while (reader.readLine().also { line = it } != null) appendLog(line ?: "")
                }
                val exitCode = process.waitFor()
                runOnUiThread {
                    status.text = "Status: selesai (exit $exitCode)"
                    runButton.isEnabled = true
                }
            } catch (e: Exception) {
                appendLog("[ERROR] ${e.message}")
                runOnUiThread {
                    status.text = "Status: gagal menjalankan script"
                    runButton.isEnabled = true
                }
            }
        }.start()
    }
}
